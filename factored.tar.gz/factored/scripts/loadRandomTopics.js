// loadRandomTopics.js
import { loadTopics } from './dataTopic.js';

export async function loadRandomTopic(
    dataFilePath,
    topicNameDisplay,
    questionCountDisplay,
    questionDisplay,
    nextQuestionBtn,
    startListenBtn,
    stopListenBtn,
    transcriptionDisplay,
    assessmentResult,
    statusMessage
) {
    const currentTopicData = await loadTopics(dataFilePath);

    if (currentTopicData) {
        topicNameDisplay.textContent = currentTopicData.topic;
        questionCountDisplay.textContent = `Questions: ${currentTopicData.questions.length}`;

        const currentQuestionIndex = -1;
        questionDisplay.textContent = "Press 'Next Question' to begin.";
        nextQuestionBtn.disabled = false;
        startListenBtn.disabled = true;
        stopListenBtn.disabled = true;
        transcriptionDisplay.textContent = '';
        assessmentResult.textContent = '';
        statusMessage.textContent = '';
        
        return { currentTopicData, currentQuestionIndex };
    } else {
        statusMessage.textContent = 'Error: Could not load questions.';
        nextQuestionBtn.disabled = true;
        return { currentTopicData: null, currentQuestionIndex: -1 };
    }
}