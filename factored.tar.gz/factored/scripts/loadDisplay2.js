// loadDisplay2.js
import { loadTopics } from './dataTopic.js';

export async function loadNewTopic(
    dataFilePath,
    topicTitle,
    topicPrompts,
    newTopicButton,
    startButton,
    statusMessage,
    timerDisplay,
    micLevelContainer,
    transcriptionText,
    assessmentResult,
    returnToPreparationState
) {
    topicTitle.textContent = 'Loading topics...';
    newTopicButton.disabled = true;
    startButton.disabled = true;

    const topic = await loadTopics(dataFilePath);

    if (topic) {
        topicTitle.textContent = topic.topic;

        topicPrompts.innerHTML = '';
        topic.questions.forEach(question => {
            const li = document.createElement('li');
            li.textContent = question;
            topicPrompts.appendChild(li);
        });

        // Reset UI
        startButton.textContent = 'Start Preparation';
        startButton.disabled = false;
        startButton.classList.remove('button-green', 'button-yellow');
        startButton.classList.add('button-red');
        transcriptionText.value = '';
        assessmentResult.innerHTML = '<p class="text-gray-500">The assessment will be shown here after you finish speaking.</p>';
        statusMessage.textContent = 'Click "Start Practice" to begin.';
        timerDisplay.textContent = '01:00';
        micLevelContainer.classList.add('hidden');
        newTopicButton.disabled = false;
        
        // Ensure the speaking state is reset
        if (returnToPreparationState) {
            returnToPreparationState();
        }

        return topic;
    } else {
        topicTitle.textContent = 'Failed to load topics. Please check the JSON file.';
        topicPrompts.innerHTML = '';
        statusMessage.textContent = '';
        return null;
    }
}