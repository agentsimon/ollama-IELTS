// common.js

import { toggleAllButtons } from './ui.js'; // Import the new function
import { analyzeText } from './analyze.js'; // Import the analyzeText function from its new home

// Function to set up SpeechRecognition
export function setupRecognition(onResult, onEnd, onError, onStart) {
    if ('webkitSpeechRecognition' in window) {
        const recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
            if (onStart) onStart();
        };

        recognition.onresult = (event) => {
            if (onResult) onResult(event);
        };

        recognition.onend = () => {
            if (onEnd) onEnd();
        };

        recognition.onerror = (event) => {
            if (onError) onError(event);
        };

        return recognition;
    } else {
        return null;
    }
}

// Function to speak a question
export function speakQuestion(question) {
    const utterance = new SpeechSynthesisUtterance(question);
    window.speechSynthesis.speak(utterance);
}

// Function to list and print all buttons and button-like links on the page
export function listButtons() {
    // Select both <button> tags and <a> tags
    const buttons = document.querySelectorAll('button, a');
    console.log('--- Listing all buttons and links on the page ---');
    buttons.forEach((button, index) => {
        const buttonText = button.textContent.trim() || 'No text';
        const buttonId = button.id ? `#${button.id}` : 'No ID';
        const buttonClass = button.className ? `.${button.className.split(' ').join('.')}` : 'No class';
        console.log(`Element ${index + 1}: Text: "${buttonText}", Selectors: ${buttonId}, ${buttonClass}`);
    });
    console.log('---------------------------------------');
}

export { analyzeText }; // This line makes the function importable from the main script