// stateManager.js
let isListening = false;
let finalTranscription = '';

export function getIsListening() {
    return isListening;
}

export function setIsListening(status) {
    isListening = status;
}

export function getFinalTranscription() {
    return finalTranscription;
}

export function setFinalTranscription(text) {
    finalTranscription = text;
}

export function clearFinalTranscription() {
    finalTranscription = '';
}

export function appendToFinalTranscription(text) {
    finalTranscription += text;
}