// analyze.js
import { toggleAllButtons } from './ui.js';
import { IELTS_PROMPT } from './prompt.js'; // Import the prompt

/**
 * Function to analyze the transcribed text using Ollama.
 * @param {string} text - The transcribed text to analyze.
 * @param {string} question - The question related to the transcribed text.
 * @param {HTMLElement} analysisDiv - The HTML element to display the analysis.
 * @param {HTMLElement} startButton - The button that starts the analysis.
 */
export async function analyzeText(text, question, analysisDiv, startButton) {
    if (!text) {
        analysisDiv.textContent = 'No text to analyze.';
        startButton.disabled = false;
        return;
    }
    analysisDiv.textContent = 'Analyzing...';
    toggleAllButtons(true);

    const prompt = `${IELTS_PROMPT}Question: "${question}"\n\nText: "${text}"\n\nAnalysis:`;
    
    try {
        const response = await fetch('http://localhost:11434/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: 'llama2',
                prompt: prompt,
                stream: false
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        analysisDiv.textContent = data.response;
    } catch (error) {
        console.error('Error:', error);
        analysisDiv.textContent = 'Error fetching analysis. Make sure an Ollama server is running.';
    } finally {
        if (startButton) {
            startButton.disabled = false;
        }
        toggleAllButtons(false);
    }
}