// dataTopic.js
export async function loadTopics(filePath) {
    try {
        const response = await fetch(filePath);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();

        if (data.topics && Array.isArray(data.topics) && data.topics.length > 0) {
            const randomIndex = Math.floor(Math.random() * data.topics.length);
            return data.topics[randomIndex];
        } else {
            console.warn('The JSON file does not contain a valid topics array or it is empty.');
            return null;
        }
    } catch (error) {
        console.error('Error loading speaking topics:', error);
        return null;
    }
}