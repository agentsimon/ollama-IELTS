// eventListeners.js
import { setupRecognition } from './speechRecognition.js';
import { startAudioProcessing, stopAudioProcessing } from './micLevel.js';
import { getIsListening, setIsListening, getFinalTranscription, appendToFinalTranscription, clearFinalTranscription } from './stateManager.js';
import { updateUIForListening, updateUIForStop, updateUIForError, displayTranscription } from './ui.js';

let recognition = null;

export function setupListening(
    startListenBtn,
    stopListenBtn,
    transcriptionDisplay,
    statusMessage,
    micLevelContainer,
    micLevelBar,
    assessmentResult,
    nextQuestionBtn,
    loadingSpinner,
    analyzeText,
    currentQuestion
) {
    const startListening = () => {
        setIsListening(true);
        clearFinalTranscription();
        displayTranscription(transcriptionDisplay, '');
        updateUIForListening(startListenBtn, stopListenBtn, statusMessage, micLevelContainer);

        startAudioProcessing(micLevelBar)
            .then(() => {
                recognition = setupRecognition(
                    (event) => { // onResult callback
                        let interimTranscription = '';
                        for (let i = event.resultIndex; i < event.results.length; ++i) {
                            if (event.results[i].isFinal) {
                                appendToFinalTranscription(event.results[i][0].transcript + ' ');
                            } else {
                                interimTranscription += event.results[i][0].transcript;
                            }
                        }
                        displayTranscription(transcriptionDisplay, getFinalTranscription() + interimTranscription);
                    },
                    () => { // onEnd callback
                        if (!getIsListening()) return;
                        setIsListening(false);
                        updateUIForStop(stopListenBtn, micLevelContainer, statusMessage, loadingSpinner);
                        analyzeText(getFinalTranscription().trim(), currentQuestion, assessmentResult, nextQuestionBtn);
                        stopAudioProcessing();
                    },
                    (event) => { // onError callback
                        console.error('Speech recognition error', event.error);
                        setIsListening(false);
                        updateUIForError(statusMessage, startListenBtn, stopListenBtn, nextQuestionBtn);
                        stopAudioProcessing();
                    },
                    () => { // onStart callback
                        setIsListening(true);
                    }
                );
                
                if (recognition) {
                    recognition.start();
                }
            })
            .catch(err => {
                console.error('Error accessing microphone:', err);
                setIsListening(false);
                updateUIForError(statusMessage, startListenBtn, stopListenBtn, nextQuestionBtn);
            });
    };

    const stopListening = () => {
        if (recognition && getIsListening()) {
            recognition.stop();
            setIsListening(false);
            statusMessage.textContent = 'Recording stopped. Analyzing...';
        }
        stopAudioProcessing();
    };

    startListenBtn.addEventListener('click', startListening);
    stopListenBtn.addEventListener('click', stopListening);
}