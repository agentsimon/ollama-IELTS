// speaking2.js
import { analyzeText, listButtons } from './common.js';
import { loadTopics } from './dataTopic.js';
import { loadNewTopic } from './loadDisplay2.js';
import { startListening, stopListening, getIsListening } from './micTranscribe2.js';

const newTopicButton = document.getElementById('new-topic-button');
const startButton = document.getElementById('start-button');
const topicTitle = document.getElementById('topic-title');
const topicPrompts = document.getElementById('topic-prompts');
const statusMessage = document.getElementById('status-message');
const timerDisplay = document.getElementById('timer-display');
const micLevelContainer = document.getElementById('mic-level-container');
const micLevelBar = document.getElementById('mic-level-bar');
const transcriptionText = document.getElementById('transcription-text');
const assessmentResult = document.getElementById('assessment-result');
const assessmentContainer = document.getElementById('assessment-container');

let currentTopic = null;
let timerInterval = null;
const preparationSeconds = 60;
const countdownSeconds = 5;
const speakingSeconds = 120;
let isPreparationPhase = true;

// Define the data file path as a variable
const dataFilePath = './data/speaking2.json';

// Utility function to format time
function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Function to start the timer
function startTimer(duration, onEnd) {
    let seconds = duration;
    timerDisplay.textContent = formatTime(seconds);
    timerInterval = setInterval(() => {
        seconds--;
        timerDisplay.textContent = formatTime(seconds);
        if (seconds <= 0) {
            clearInterval(timerInterval);
            if (onEnd) onEnd();
        }
    }, 1000);
}

// Function to handle the start of the speaking phase
function startSpeakingPhase() {
    isPreparationPhase = false;
    statusMessage.textContent = 'Time to speak! You have 2 minutes.';
    newTopicButton.disabled = true;

    startListening(
        transcriptionText,
        statusMessage,
        micLevelContainer,
        startButton,
        micLevelBar,
        assessmentResult,
        newTopicButton,
        returnToPreparationState
    );
    
    startTimer(speakingSeconds, () => {
        if (getIsListening()) {
            stopListening(statusMessage, returnToPreparationState);
        }
    });
}

// Function to return to the preparation state
function returnToPreparationState() {
    isPreparationPhase = true;
    clearInterval(timerInterval);
    startButton.textContent = 'Start Preparation';
    startButton.disabled = false;
    startButton.classList.remove('button-green', 'button-yellow');
    startButton.classList.add('button-red');
    timerDisplay.textContent = '01:00';
    micLevelContainer.classList.add('hidden');
    newTopicButton.disabled = false;
    statusMessage.textContent = 'Analysis complete. Click "Start Preparation" to begin a new session.';
}

// Event listeners
newTopicButton.addEventListener('click', async () => {
    currentTopic = await loadNewTopic(
        dataFilePath,
        topicTitle,
        topicPrompts,
        newTopicButton,
        startButton,
        statusMessage,
        timerDisplay,
        micLevelContainer,
        transcriptionText,
        assessmentResult,
        returnToPreparationState
    );
});

startButton.addEventListener('click', () => {
    if (isPreparationPhase) {
        statusMessage.textContent = 'You have 1 minute to prepare. The timer will start now.';
        startButton.textContent = 'Prepare (1:00)';
        startButton.disabled = true;
        startButton.classList.remove('button-red');
        startButton.classList.add('button-yellow');
        newTopicButton.disabled = true;
        startTimer(preparationSeconds, () => {
            statusMessage.textContent = 'Get Ready! Speaking starts in...';
            startTimer(countdownSeconds, startSpeakingPhase);
        });
    } else {
        if (getIsListening()) {
            stopListening(statusMessage, returnToPreparationState);
        } else {
            startSpeakingPhase();
        }
    }
});

// Initial load
(async () => {
    currentTopic = await loadNewTopic(
        dataFilePath,
        topicTitle,
        topicPrompts,
        newTopicButton,
        startButton,
        statusMessage,
        timerDisplay,
        micLevelContainer,
        transcriptionText,
        assessmentResult,
        returnToPreparationState
    );
})();

// Call the function to list the buttons after the DOM is ready
//document.addEventListener('DOMContentLoaded', () => {
//  listButtons();
//});