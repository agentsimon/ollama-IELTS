// speaking1.js
import { setupRecognition, analyzeText, speakQuestion, listButtons } from './common.js';
import { setupListening } from './listening.js';
import { loadTopics } from './dataTopic.js';
import { handleQuestionFlow } from './questionFlow.js';
import { loadRandomTopic } from './loadRandomTopics.js';

const nextQuestionBtn = document.getElementById('next-question-btn');
const startListenBtn = document.getElementById('start-listen-btn');
const stopListenBtn = document.getElementById('stop-listen-btn');
const questionDisplay = document.getElementById('question-display');
const statusMessage = document.getElementById('status-message');
const transcriptionDisplay = document.getElementById('transcription-display');
const assessmentResult = document.getElementById('assessment-result');
const micLevelBar = document.getElementById('mic-level-bar');
const micLevelContainer = document.getElementById('mic-level-container');
const loadingSpinner = document.getElementById('loading-spinner');
const topicNameDisplay = document.getElementById('topic-name');
const questionCountDisplay = document.getElementById('question-count');

let currentQuestionIndex = -1;
let currentTopicData = null;
let currentQuestion = ''; // New variable to store the current question

// Define the Ollama model to be used
const OLLAMA_MODEL = 'llama3'; // Add this constant

// Define the data file path as a variable
const dataFilePath = './data/speaking1.json';

// Function to handle the initial setup and update state variables
async function initializeApp() {
    const data = await loadRandomTopic(
        dataFilePath,
        topicNameDisplay,
        questionCountDisplay,
        questionDisplay,
        nextQuestionBtn,
        startListenBtn,
        stopListenBtn,
        transcriptionDisplay,
        assessmentResult,
        statusMessage
    );
    currentTopicData = data.currentTopicData;
    currentQuestionIndex = data.currentQuestionIndex;
}

// Event Listeners
nextQuestionBtn.addEventListener('click', () => {
    currentQuestionIndex = handleQuestionFlow(
        currentQuestionIndex,
        currentTopicData,
        questionDisplay,
        statusMessage,
        nextQuestionBtn,
        startListenBtn,
        stopListenBtn,
        assessmentResult,
        transcriptionDisplay
    );
    // After handling the question flow, update the currentQuestion variable
    currentQuestion = questionDisplay.textContent;
    // Call the new setup function to handle all listening logic
    setupListening(
        startListenBtn,
        stopListenBtn,
        transcriptionDisplay,
        statusMessage,
        micLevelContainer,
        micLevelBar,
        assessmentResult,
        nextQuestionBtn,
        loadingSpinner,
        currentQuestion,
        OLLAMA_MODEL // Pass the model name here
    );
});

// Initial load
initializeApp();