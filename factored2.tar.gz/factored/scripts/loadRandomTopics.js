// loadRandomTopics.js
import { loadTopics } from './dataTopic.js';

export async function loadRandomTopic(
    dataFilePath,
    topicNameDisplay,
    questionCountDisplay,
    questionDisplay,
    nextQuestionBtn,
    startListenBtn,
    stopListenBtn,
    transcriptionDisplay,
    assessmentResult,
    statusMessage
) {
    try {
        const data = await loadTopics(dataFilePath);
        console.log('Full data object:', data);
        
        // Ensure data is valid and has a topics array
        if (!data || !data.topics || data.topics.length === 0) {
            console.error('Data is not in the expected format or the topics array is empty.');
            statusMessage.textContent = 'Error: No topics available in the data file.';
            return { currentTopicData: null, currentQuestionIndex: -1 };
        }
        
        const topics = data.topics;
        const randomIndex = Math.floor(Math.random() * topics.length);
        const currentTopicData = topics[randomIndex];
        
        if (!currentTopicData || !currentTopicData.questions || currentTopicData.questions.length === 0) {
            console.error('Selected topic is missing questions.');
            statusMessage.textContent = 'Error: The selected topic has no questions.';
            return { currentTopicData: null, currentQuestionIndex: -1 };
        }
        
        // Display topic name
        topicNameDisplay.textContent = currentTopicData.topic;
        
        // Reset and display first question
        const currentQuestionIndex = 0;
        questionDisplay.textContent = currentTopicData.questions[currentQuestionIndex];
        questionCountDisplay.textContent = `Question ${currentQuestionIndex + 1} of ${currentTopicData.questions.length}`;

        // Reset UI state
        statusMessage.textContent = 'Click "Start Practice" to begin.';
        transcriptionDisplay.textContent = '';
        assessmentResult.textContent = '';
        nextQuestionBtn.disabled = false;
        startListenBtn.disabled = false;
        stopListenBtn.disabled = true;

        console.log('Current Topic Data:', currentTopicData);
        console.log('First Question:', currentTopicData.questions[currentQuestionIndex]);
        
        return { currentTopicData, currentQuestionIndex };
    } catch (error) {
        console.error('Failed to load random topic:', error);
        statusMessage.textContent = 'Error: Failed to load topic. Check the console for details.';
        return { currentTopicData: null, currentQuestionIndex: -1 };
    }
}
