// micLevel.js
let audioContext = null;
let microphone = null;
let audioWorkletNode = null;
let isAudioProcessing = false;

// Make the entire function async
export async function startAudioProcessing(micLevelBar) {
    if (isAudioProcessing) return;

    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        
        // Load and register the audio worklet module
        await audioContext.audioWorklet.addModule('./scripts/audio-processor.js');

        microphone = audioContext.createMediaStreamSource(stream);
        
        // Create the AudioWorkletNode, passing the name we registered
        audioWorkletNode = new AudioWorkletNode(audioContext, 'mic-level-processor');
        
        // Listen for messages from the AudioWorklet
        audioWorkletNode.port.onmessage = (event) => {
            const normalizedVolume = event.data;
            if (micLevelBar) {
                micLevelBar.style.width = `${normalizedVolume * 100}%`;
            }
        };
        
        // Connect the nodes
        microphone.connect(audioWorkletNode);
        audioWorkletNode.connect(audioContext.destination);

        isAudioProcessing = true;
        return stream;
    } catch (err) {
        console.error('Error accessing microphone:', err);
        throw err; // Re-throw the error so the calling function can handle it
    }
}

export function stopAudioProcessing() {
    if (!isAudioProcessing) return;

    if (audioWorkletNode) {
        audioWorkletNode.disconnect();
        audioWorkletNode = null;
    }
    if (microphone) {
        microphone.disconnect();
        microphone = null;
    }
    if (audioContext) {
        audioContext.close();
        audioContext = null;
    }
    isAudioProcessing = false;
}