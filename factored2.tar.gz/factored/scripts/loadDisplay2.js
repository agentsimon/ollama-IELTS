// loadDisplay2.js
import { loadTopics } from './dataTopic.js';

export async function loadNewTopic(
    dataFilePath,
    topicTitle,
    topicPrompts,
    newTopicButton,
    startButton,
    statusMessage,
    timerDisplay,
    micLevelContainer,
    transcriptionText,
    assessmentResult,
    returnToPreparationState
) {
    try {
        const data = await loadTopics(dataFilePath);
        console.log('Fetched full data object:', data);
        
        // Ensure data is valid and has a topics array
        if (!data || !data.topics || data.topics.length === 0) {
            console.error('Data is not in the expected format or the topics array is empty.');
            statusMessage.textContent = 'Error: No topics available in the data file.';
            return null;
        }

        const topics = data.topics;
        const randomIndex = Math.floor(Math.random() * topics.length);
        const newTopic = topics[randomIndex];
        
        console.log('Selected new topic:', newTopic); // Log the selected topic

        // Check if the topic and its 'questions' array exist
        if (!newTopic || !newTopic.questions || newTopic.questions.length === 0) {
            console.error('Failed to select a new topic or the topic has no questions.');
            statusMessage.textContent = 'Error: Failed to select a topic with questions.';
            return null;
        }

        // Clear previous content
        topicTitle.textContent = '';
        topicPrompts.innerHTML = '';
        transcriptionText.value = '';
        assessmentResult.textContent = '';
        
        // Update topic title and questions
        topicTitle.textContent = newTopic.topic;
        newTopic.questions.forEach(question => {
            const li = document.createElement('li');
            li.textContent = question;
            li.className = 'text-gray-600 mb-2';
            topicPrompts.appendChild(li);
        });

        // Reset and prepare UI
        returnToPreparationState();

        return newTopic;
    } catch (error) {
        console.error('Error loading new topic:', error);
        statusMessage.textContent = 'Error loading topic data. Check the console for details.';
        return null;
    }
}
