// dataTopic.js
/**
 * Fetches the topics from a JSON file.
 * @param {string} filePath - The path to the JSON file.
 * @returns {Promise<Object>} A promise that resolves with the parsed JSON data.
 */
export async function loadTopics(filePath) {
    try {
        const response = await fetch(filePath);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        // Log the fetched data to the console for debugging
        console.log('Data fetched successfully:', data);
        return data;
    } catch (error) {
        console.error('Failed to load topics:', error);
        return null; // Return null on error to prevent further issues
    }
}
