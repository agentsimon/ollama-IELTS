// listening.js
import { toggleAllButtons } from './ui.js';
import { startAudioProcessing, stopAudioProcessing } from './micLevel.js';
import { setupRecognition } from './speechRecognition.js';
import { analyzeText } from './common.js';

export function setupListening(
    startListenBtn,
    stopListenBtn,
    transcriptionDisplay,
    statusMessage,
    micLevelContainer,
    micLevelBar,
    assessmentResult,
    nextQuestionBtn,
    loadingSpinner,
    currentQuestion,
    modelName // Add the new parameter here
) {
    let recognition = null;
    let isListening = false;
    let finalTranscription = '';

    const startListening = () => {
        isListening = true;
        finalTranscription = '';
        transcriptionDisplay.textContent = '';
        statusMessage.textContent = 'Microphone active. Please speak now.';

        if (startListenBtn === stopListenBtn) {
            startListenBtn.textContent = 'Stop Listening';
            startListenBtn.classList.remove('button-red');
            startListenBtn.classList.add('button-green');
        } else {
            startListenBtn.disabled = true;
            stopListenBtn.disabled = false;
        }

        micLevelContainer.classList.remove('hidden');

        startAudioProcessing(micLevelBar)
            .then(() => {
                recognition = setupRecognition(
                    (event) => { // onResult callback
                        let interimTranscription = '';
                        for (let i = event.resultIndex; i < event.results.length; ++i) {
                            if (event.results[i].isFinal) {
                                finalTranscription += event.results[i][0].transcript + ' ';
                            } else {
                                interimTranscription += event.results[i][0].transcript;
                            }
                        }
                        transcriptionDisplay.textContent = finalTranscription + interimTranscription;
                    },
                    () => { // onEnd callback
                        isListening = false;
                        stopAudioProcessing();
                        statusMessage.textContent = 'Recording stopped. Analyzing...';
                        analyzeText(finalTranscription.trim(), currentQuestion, assessmentResult, startListenBtn, modelName).then(() => {
                            // Re-enable start button here if needed
                        });
                    },
                    (event) => { // onError callback
                        console.error('Speech recognition error', event.error);
                        statusMessage.textContent = 'Error: ' + event.error;

                        if (startListenBtn === stopListenBtn) {
                            startListenBtn.textContent = 'Start Practice';
                            startListenBtn.classList.remove('button-green');
                            startListenBtn.classList.add('button-red');
                        } else {
                            startListenBtn.disabled = false;
                            stopListenBtn.disabled = true;
                        }
                        micLevelContainer.classList.add('hidden');
                        stopAudioProcessing();
                    },
                    () => { // onStart callback
                        isListening = true;
                    }
                );

                if (recognition) {
                    recognition.start();
                }
            })
            .catch(err => {
                console.error('Error accessing microphone:', err);
                statusMessage.textContent = 'Error: Could not access microphone.';

                if (startListenBtn === stopListenBtn) {
                    startListenBtn.textContent = 'Start Practice';
                    startListenBtn.classList.remove('button-green');
                    startListenBtn.classList.add('button-red');
                } else {
                    startListenBtn.disabled = false;
                    stopListenBtn.disabled = true;
                }
                micLevelContainer.classList.add('hidden');
            });
    };

    const stopListening = () => {
        if (recognition && isListening) {
            recognition.stop();
            stopAudioProcessing();
            statusMessage.textContent = 'Recording stopped. Analyzing...';
        }
    };

    startListenBtn.addEventListener('click', () => {
        if (isListening) {
            stopListening();
        } else {
            startListening();
        }
    });

    if (startListenBtn !== stopListenBtn) {
        stopListenBtn.addEventListener('click', stopListening);
    }
}