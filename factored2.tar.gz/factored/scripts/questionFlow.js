// questionFlow.js
import { speakQuestion } from './common.js';

export function handleQuestionFlow(
    currentQuestionIndex,
    currentTopicData,
    questionDisplay,
    statusMessage,
    nextQuestionBtn,
    startListenBtn,
    stopListenBtn,
    assessmentResult,
    transcriptionDisplay
) {
    assessmentResult.textContent = '';
    transcriptionDisplay.textContent = '';
    currentQuestionIndex++;

    if (currentTopicData && currentQuestionIndex < currentTopicData.questions.length) {
        const currentQuestion = currentTopicData.questions[currentQuestionIndex];
        questionDisplay.textContent = currentQuestion;
        statusMessage.textContent = 'Listening for a moment...';
        nextQuestionBtn.disabled = true;
        startListenBtn.disabled = true;

        speakQuestion(currentQuestion);

        setTimeout(() => {
            statusMessage.textContent = 'Ready to record. Press "Start Answer" when you are ready.';
            startListenBtn.disabled = false;
        }, 1500);
    } else {
        questionDisplay.textContent = 'End of topic. Thanks for practicing!';
        statusMessage.textContent = '';
        nextQuestionBtn.disabled = false;
        startListenBtn.disabled = true;
        stopListenBtn.disabled = true;
    }

    return currentQuestionIndex;
}