// speechRecognition.js
export function setupRecognition(onResult, onEnd, onError, onStart) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        console.error("Speech Recognition is not supported by this browser.");
        return null;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = onResult;
    recognition.onend = onEnd;
    recognition.onerror = onError;
    recognition.onstart = onStart;

    return recognition;
}