// micTranscribe2.js
import { startAudioProcessing, stopAudioProcessing } from './micLevel.js';
import { setupRecognition } from './speechRecognition.js';
import { analyzeText } from './common.js';

let recognition = null;
let finalTranscription = '';

// The state is managed within this module
const state = {
    isListening: false,
};

// Function to start the microphone and speech recognition
export const startListening = (
    transcriptionText,
    statusMessage,
    micLevelContainer,
    startButton,
    micLevelBar,
    assessmentResult,
    newTopicButton,
    returnToPreparationState,
    currentQuestion,
    modelName // Add the new parameter here
) => {
    state.isListening = true;
    finalTranscription = '';
    transcriptionText.value = '';
    statusMessage.textContent = 'Microphone active. Please speak now.';
    micLevelContainer.classList.remove('hidden');
    startButton.textContent = 'Recording';
    startButton.classList.remove('button-yellow', 'button-red');
    startButton.classList.add('button-green');

    startAudioProcessing(micLevelBar)
        .then(() => {
            recognition = setupRecognition(
                (event) => { // onResult callback
                    let interimTranscription = '';
                    for (let i = event.resultIndex; i < event.results.length; ++i) {
                        if (event.results[i].isFinal) {
                            finalTranscription += event.results[i][0].transcript + ' ';
                        } else {
                            interimTranscription += event.results[i][0].transcript;
                        }
                    }
                    transcriptionText.value = finalTranscription + interimTranscription;
                },
                () => { // onEnd callback
                    state.isListening = false;
                    statusMessage.textContent = 'Speech ended. Analyzing...';
                    startButton.textContent = 'Analyzing...';
                    startButton.disabled = true;
                    startButton.classList.remove('button-green');
                    startButton.classList.add('button-yellow');
                    micLevelContainer.classList.add('hidden');
                    analyzeText(finalTranscription.trim(), currentQuestion, assessmentResult, startButton, modelName).then(() => {
                        returnToPreparationState();
                    });
                    stopAudioProcessing();
                },
                (event) => { // onError callback
                    console.error('Speech recognition error', event.error);
                    statusMessage.textContent = 'Error: ' + event.error;
                    returnToPreparationState();
                },
                () => { // onStart callback
                    state.isListening = true;
                }
            );

            if (recognition) {
                recognition.start();
            }
        })
        .catch(err => {
            console.error('Error accessing microphone:', err);
            statusMessage.textContent = 'Error: Could not access microphone.';
            returnToPreparationState();
        });
};

// Function to stop the microphone and speech recognition
export const stopListening = (statusMessage, returnToPreparationState) => {
    if (recognition && state.isListening) {
        recognition.stop();
        stopAudioProcessing();
        statusMessage.textContent = 'Recording stopped. Analyzing...';
        state.isListening = false;
        recognition.onend();
    }
};

// Expose the listening state for other scripts to check
export const getIsListening = () => state.isListening;