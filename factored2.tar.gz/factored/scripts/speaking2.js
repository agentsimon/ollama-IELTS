// speaking2.js
import { analyzeText, listButtons } from './common.js';
import { loadTopics } from './dataTopic.js';
import { loadNewTopic } from './loadDisplay2.js';
import { startListening, stopListening, getIsListening } from './micTranscribe2.js';
import { formatTime, startTimer } from './timers2.js';

let currentTopic = null;
let timerInterval = null;
const preparationSeconds = 60;
const countdownSeconds = 5;
const speakingSeconds = 120;
let isPreparationPhase = true;

// Define the Ollama model to be used
const OLLAMA_MODEL = 'llama3';

// Define the data file path as a variable
const dataFilePath = './data/speaking2.json';

// Function to handle the start of the speaking phase
function startSpeakingPhase() {
    isPreparationPhase = false;
    statusMessage.textContent = 'Time to speak! You have 2 minutes.';
    newTopicButton.disabled = true;

    startListening(
        transcriptionText,
        statusMessage,
        micLevelContainer,
        startButton,
        micLevelBar,
        assessmentResult,
        newTopicButton,
        returnToPreparationState,
        currentTopic.question,
        OLLAMA_MODEL
    );
    
    // Use the new startTimer function from timers2.js
    timerInterval = startTimer(speakingSeconds, timerDisplay, () => {
        if (getIsListening()) {
            stopListening(statusMessage, returnToPreparationState);
        }
    });
}

// Function to return to the preparation state
function returnToPreparationState() {
    isPreparationPhase = true;
    if (timerInterval) {
        clearInterval(timerInterval);
    }
    startButton.textContent = 'Start Preparation';
    startButton.disabled = false;
    startButton.classList.remove('button-green', 'button-yellow');
    startButton.classList.add('button-red');
    timerDisplay.textContent = formatTime(preparationSeconds);
    micLevelContainer.classList.add('hidden');
    newTopicButton.disabled = false;
    statusMessage.textContent = 'Analysis complete. Click "Start Preparation" to begin a new session.';
}

// Get all the necessary DOM elements once the page is ready
let newTopicButton, startButton, topicTitle, topicPrompts, statusMessage, timerDisplay, micLevelContainer, micLevelBar, transcriptionText, assessmentResult, assessmentContainer;

function initializeElements() {
    newTopicButton = document.getElementById('new-topic-button');
    startButton = document.getElementById('start-button');
    topicTitle = document.getElementById('topic-title');
    topicPrompts = document.getElementById('topic-prompts');
    statusMessage = document.getElementById('status-message');
    timerDisplay = document.getElementById('timer-display');
    micLevelContainer = document.getElementById('mic-level-container');
    micLevelBar = document.getElementById('mic-level-bar');
    transcriptionText = document.getElementById('transcription-text');
    assessmentResult = document.getElementById('assessment-result');
    assessmentContainer = document.getElementById('assessment-container');
}

// The main initialization function
async function initializeApp() {
    initializeElements();

    if (!newTopicButton || !startButton) {
        console.error("Error: One or more key elements not found in the DOM.");
        return;
    }
    
    // Initial load
    currentTopic = await loadNewTopic(
        dataFilePath,
        topicTitle,
        topicPrompts,
        newTopicButton,
        startButton,
        statusMessage,
        timerDisplay,
        micLevelContainer,
        transcriptionText,
        assessmentResult,
        returnToPreparationState
    );

    // Event listeners
    newTopicButton.addEventListener('click', async () => {
        currentTopic = await loadNewTopic(
            dataFilePath,
            topicTitle,
            topicPrompts,
            newTopicButton,
            startButton,
            statusMessage,
            timerDisplay,
            micLevelContainer,
            transcriptionText,
            assessmentResult,
            returnToPreparationState
        );
    });

    startButton.addEventListener('click', () => {
        if (isPreparationPhase) {
            statusMessage.textContent = 'You have 1 minute to prepare. The timer will start now.';
            startButton.textContent = 'Prepare (1:00)';
            startButton.disabled = true;
            startButton.classList.remove('button-red');
            startButton.classList.add('button-yellow');
            newTopicButton.disabled = true;
            
            // Use the new startTimer function from timers2.js
            timerInterval = startTimer(preparationSeconds, timerDisplay, () => {
                statusMessage.textContent = 'Get Ready! Speaking starts in...';
                // After preparation, start the 5-second countdown
                timerInterval = startTimer(countdownSeconds, timerDisplay, startSpeakingPhase);
            });
        } else {
            if (getIsListening()) {
                stopListening(statusMessage, returnToPreparationState);
            } else {
                startSpeakingPhase();
            }
        }
    });
}

// Start the application when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', initializeApp);
