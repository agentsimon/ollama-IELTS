// A utility function to format time in MM:SS format.
export function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

/**
 * Starts a countdown timer and updates the display.
 * @param {number} duration - The duration of the timer in seconds.
 * @param {HTMLElement} timerDisplay - The element to update with the time.
 * @param {Function} onEnd - The function to call when the timer ends.
 * @returns {number} The interval ID for the timer.
 */
export function startTimer(duration, timerDisplay, onEnd) {
    let seconds = duration;
    timerDisplay.textContent = formatTime(seconds);
    const intervalId = setInterval(() => {
        seconds--;
        timerDisplay.textContent = formatTime(seconds);
        if (seconds <= 0) {
            clearInterval(intervalId);
            if (onEnd) onEnd();
        }
    }, 1000);
    return intervalId;
}
