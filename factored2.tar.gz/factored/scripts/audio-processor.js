// This script runs in a separate thread and cannot directly access the DOM.

// Define a class that extends AudioWorkletProcessor
class MicLevelProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    // This port is used to communicate with the main thread
    this.port.onmessage = (event) => {
      // Handle messages from the main thread if needed
      // (not necessary for this use case, but good to know)
    };
  }

  // The process method is called for each block of audio data
  process(inputs, outputs, parameters) {
    const input = inputs[0];
    if (input.length > 0) {
      const inputChannel = input[0];
      
      // Calculate the RMS (root mean square) to get the volume level
      let sum = 0;
      for (let i = 0; i < inputChannel.length; i++) {
        sum += inputChannel[i] * inputChannel[i];
      }
      const rms = Math.sqrt(sum / inputChannel.length);
      
      // The rms is a value between 0 and 1. We'll send it back to the main thread.
      this.port.postMessage(rms);
    }
    
    // Return true to keep the processor active
    return true;
  }
}

// Register the processor with a name
registerProcessor('mic-level-processor', MicLevelProcessor);