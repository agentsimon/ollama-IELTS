// ui.js
export function updateUIForListening(
    startListenBtn,
    stopListenBtn,
    statusMessage,
    micLevelContainer
) {
    startListenBtn.disabled = true;
    stopListenBtn.disabled = false;
    statusMessage.textContent = 'Microphone active. Please speak now.';
    micLevelContainer.classList.remove('hidden');
}

export function updateUIForStop(
    stopListenBtn,
    micLevelContainer,
    statusMessage,
    loadingSpinner
) {
    stopListenBtn.disabled = true;
    micLevelContainer.classList.add('hidden');
    statusMessage.textContent = 'Speech ended. Analyzing...';
    //loadingSpinner.classList.remove('hidden');
}

export function updateUIForError(
    statusMessage,
    startListenBtn,
    stopListenBtn,
    nextQuestionBtn
) {
    statusMessage.textContent = 'Error: Could not access microphone.';
    startListenBtn.disabled = false;
    stopListenBtn.disabled = true;
    nextQuestionBtn.disabled = false;
}

export function displayTranscription(transcriptionDisplay, transcription) {
    transcriptionDisplay.textContent = transcription;
}

export function toggleControls(disabled) {
    const speaking1Link = document.getElementById("speaking-1-link");
    const speaking3Link = document.getElementById("speaking-3-link");
    const newTopicButton = document.getElementById("new-topic-button");
    const startButton = document.getElementById("start-button");

    if (disabled) {
        speaking1Link.classList.add("disabled-link");
        speaking3Link.classList.add("disabled-link");
        newTopicButton.disabled = true;
        startButton.disabled = true;
    } else {
        speaking1Link.classList.remove("disabled-link");
        speaking3Link.classList.remove("disabled-link");
        newTopicButton.disabled = false;
        startButton.disabled = false;
    }
}

export function toggleNavButtons(disabled) {
    const speaking2Link = document.getElementById("speaking-2-link");
    const speaking3Link = document.getElementById("speaking-3-link");

    if (disabled) {
        speaking2Link.classList.add("disabled-style");
        speaking3Link.classList.add("disabled-style");
    } else {
        speaking2Link.classList.remove("disabled-style");
        speaking3Link.classList.remove("disabled-style");
    }
}

export function toggleAllButtons(disabled) {
    const buttons = document.querySelectorAll('button, a');
    buttons.forEach(button => {
        if (button.tagName === 'BUTTON') {
            button.disabled = disabled;
        }
        if (disabled) {
            button.classList.add('disabled-style');
        } else {
            button.classList.remove('disabled-style');
        }
    });
}